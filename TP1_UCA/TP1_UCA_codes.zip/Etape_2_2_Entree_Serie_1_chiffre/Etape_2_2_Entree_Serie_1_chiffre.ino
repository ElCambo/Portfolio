// Etape_2_2_Entree_Serie_1_chiffre
// Le code est écrit en C++ : voir main.cpp (setup/loop) et les classes .h/.cpp de ce dossier.
// Ce fichier .ino doit exister (même nom que le dossier) pour que l'Arduino IDE ouvre le projet.
